import os
import logging
import sys
import gensim
from collections import deque
import pymysql;
import pandas as pd
import numpy as np
import jieba
import jieba.posseg as pseg
from utils import (
    get_logger,
    similarity,
)


jieba.dt.tmp_dir = "./"
jieba.default_logger.setLevel(logging.ERROR)
logger = get_logger('faqrobot', logfile="faqrobot.log")

class zhishiku(object):
    def __init__(self):  # a是答案（必须是1给）, q是问题（1个或多个）
        self.ques = []
        self.sim = []
        self.q_vec = []
        self.q_word = []
        self.ans_id = []
        self.que_id = []

    def __str__(self):
        return 'q=' + str(self.ques) + '\na=' + '\nq_word=' + str(self.q_word) + '\nq_vec=' + str(self.q_vec)
        # return 'a=' + str(self.a) + '\nq=' + str(self.q)


class FAQrobot(object):
    def __init__(self, lastTxtLen=10, usedVec=False):
        # usedVec 如果是True 在初始化时会解析词向量，加快计算句子相似度的速度
        self.lastTxt = deque([], lastTxtLen)
        self.usedVec = usedVec
        self.reload()

    def load_sql(self):
        
        self.zhishiku = zhishiku()
        db = pymysql.connect(host="localhost", user="root", password="Practice2021.", db="QA")
        cur = db.cursor()
        sql = 'select content from question;'
        df = pd.read_sql(sql, con=db)
        df1 = np.array(df)#先使用array()将DataFrame转换一下
        df2 = df1.tolist()#再将转换后的数据用tolist()转成列表
        for t in df2:
            for a in t:
                self.zhishiku.ques.append(a)
        sql = 'select answer_id from question;'
        df = pd.read_sql(sql, con=db)
        df1 = np.array(df)#先使用array()将DataFrame转换一下
        df2 = df1.tolist()#再将转换后的数据用tolist()转成列表
        for t in df2:
            for a in t:
                self.zhishiku.ans_id.append(a)
        sql = 'select question_id from question;'
        df = pd.read_sql(sql, con=db)
        df1 = np.array(df)#先使用array()将DataFrame转换一下
        df2 = df1.tolist()#再将转换后的数据用tolist()转成列表
        for t in df2:
            for a in t:
                self.zhishiku.que_id.append(a)
        db.close()
        self.zhishiku.ques
        for question in self.zhishiku.ques:
            self.zhishiku.q_word.append(set(jieba.cut(question)))

    def load_embedding(self):
        from gensim.models import Word2Vec
        if not os.path.exists('Word60.model'):
            self.vecModel = None
            return

        # 载入60维的词向量(Word60.model，Word60.model.syn0.npy，Word60.model.syn1neg.npy）
        self.vecModel = Word2Vec.load('Word60.model')
        for t in self.zhishiku:
            t.q_vec = []
            for question in t.q_word:
                t.q_vec.append({t for t in question if t in self.vecModel.index2word})

    def reload(self):
        self.load_sql()
        self.load_embedding()

    def maxSimTxt(self, intxt, simCondision=0.5, simType='simple'):
        """
        找出知识库里的和输入句子相似度最高的句子
        simType=simple, simple_POS, vec
        """
        self.lastTxt.append(intxt)
        if simType not in ('simple', 'simple_pos', 'vec'):
            return 'error:  maxSimTxt的simType类型不存在: {}'.format(simType)

        # 如果没有加载词向量，那么降级成 simple_pos 方法
        embedding = self.vecModel
        if simType == 'vec' and not embedding:
            simType = 'simple_pos'

        questions = self.zhishiku.q_vec if simType == 'vec' else self.zhishiku.q_word
        in_vec = jieba.lcut(intxt) if simType == 'simple' else pseg.lcut(intxt)
        nowMax = 0
        ansid = 0
        queid = 0
        for inx, question in enumerate(questions):
            x = similarity(in_vec, question, method=simType, embedding=embedding)
            if nowMax < x:
                ansid = self.zhishiku.ans_id[inx]
                nowMax = x
                queid = self.zhishiku.que_id[inx]
        logger.info('maxSim=' + format(nowMax, '.0%'))
        if nowMax < simCondision:
            db = pymysql.connect(host="localhost", user="root", password="Practice2021.", db="QA")
            cur = db.cursor()
            sql = "select collect_id from collect where content = '%s';" % intxt
            df = pd.read_sql(sql, con=db)
            df1 = np.array(df)#先使用array()将DataFrame转换一下
            df2 = df1.tolist()#再将转换后的数据用tolist()转成列表
            if len(df2) == 0:
                cur.execute("insert into collect(content) values('%s');" % intxt)
                db.commit()
            db.close()
            return '抱歉，我没有理解您的意思。'

        db = pymysql.connect(host="localhost", user="root", password="Practice2021.", db="QA")
        cur = db.cursor()
        sql = "select content from answer where answer_id = %s;" % ansid
        df = pd.read_sql(sql, con=db)
        df1 = np.array(df)#先使用array()将DataFrame转换一下
        df2 = df1.tolist()#再将转换后的数据用tolist()转成列表
        sql = "update question set num = num + 1 where question_id = %s" % queid
        cur.execute(sql)
        db.commit()
        db.close()
        # if len(df2) == 0:
        #         db = pymysql.connect(host="localhost", user="root", password="Practice2021.", db="QA")
        #         cur = db.cursor()
        #         sql = "insert into collect(content) values('%s');" % intxt
        #         cur.execute(sql)
        #         db.commit()
        #         db.close()
        #         return '抱歉，我没有理解您的意思。'
        # for t in df2:
        #     if len(t) == 0:
        #         db = pymysql.connect(host="localhost", user="root", password="Practice2021.", db="QA")
        #         cur = db.cursor()
        #         sql = "insert into collect(content) values('%s');" % intxt
        #         cur.execute(sql)
        #         db.commit()
        #         db.close()
        #         return '抱歉，我没有理解您的意思。'
        for t in df2:
            for a in t:
                return a

    def answer(self, intxt, simType='simple'):
        """simType=simple, simple_POS, vec, all"""
        if not intxt:
            return ''

        if simType == 'all':  # 用于测试不同类型方法的准确度，返回空文本
            for method in ('simple', 'simple_pos', 'vec'):
                outtext = 'method:\t' + self.maxSim(intxt, simType=method)
                print(outtext)
            return ''
        else:
            outtxt = self.maxSimTxt(intxt, simType=simType)
            # 输出回复内容，并计入日志
        return outtxt

def solve(xxx):
    print('回复：' + robot.answer(xxx, 'simple_pos'))

if __name__ == '__main__':
    robot = FAQrobot(usedVec=False)
    solve(sys.argv[1])
        
