#_*_coding:UTF-8_*_

import sys
import time

def test(str):
    print("python处理后的消息[" + str + "]")
if __name__ == '__main__':
    test(str = sys.argv[1])