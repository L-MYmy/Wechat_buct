<?php
echo "11\n";
include_once "./src1/master/api/examples/MessageTest.php";