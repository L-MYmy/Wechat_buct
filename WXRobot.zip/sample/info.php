<?php
include_once "WXBizMsgCrypt.php";

$encodingAesKey = "Pvp38oNMtj55I8RKFMOkHGvDT4I8Ys83jwq5C2C84W6";
$token = "nothG9PwMgHuPZPPX";
$receiveid = "ww9a6302cc547b2335";


$wxcpt = new WXBizMsgCrypt($token, $encodingAesKey, $receiveid);

// get the paramters
$sVerifyMsgSig = $_GET['msg_signature'];
$sVerifyTimeStamp = $_GET['timestamp'];
$sVerifyNonce = $_GET['nonce'];
$sVerifyEchoStr = $_GET['echostr'];

$sEchoStr = "";

// call verify function
$errCode = $wxcpt->VerifyURL($sVerifyMsgSig, $sVerifyTimeStamp, $sVerifyNonce, $sVerifyEchoStr, $sEchoStr);
if ($errCode == 0) {
	echo $sEchoStr . "\n";
} else {
	print("ERR: " . $errCode . "\n\n");
}