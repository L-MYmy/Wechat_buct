<?php
 echo "22 ";
include_once("MessageTest.php");