<?php
include_once "/var/www/html/sample/WXBizMsgCrypt.php";

// include_once("../src/CorpAPI.class.php");
// include_once("../src/ServiceCorpAPI.class.php");
// include_once("../src/ServiceProviderAPI.class.php");


// $config = require('config.php');
// $agentId = $config['APP_ID'];
// $api = new CorpAPI($config['CORP_ID'], $config['APP_SECRET']);

// 假设企业号在公众平台上设置的参数如下

$encodingAesKey = "x5WQ2ckpTWxVjBrH72t4H0j8AW2THHFsJz6HvvoQDad";
$token = "yws2pgg8";
$receiveid = "wwbf080900d0f74e95";


$wxcpt = new WXBizMsgCrypt($token, $encodingAesKey, $receiveid);

// http://cq.xuduan.tech:62606/weworkapi_php/callback_json/callbackverify.php?msg_signature=5c45ff5e21c57e6ad56bac8758b79b1d9ac89fd3&timestamp=1409659589&nonce=263014780&echostr=P9nAzCzyDtyTWESHep1vC5X9xho%2FqYX3Zpb4yKa9SKld1DsH3Iyt3tP3zNdtp%2B4RPcs8TgAE7OaBO%2BFZXvnaqQ%3D%3D
//
// get the paramters
$sVerifyMsgSig = $_GET['msg_signature'];
$sVerifyTimeStamp = $_GET['timestamp'];
$sVerifyNonce = $_GET['nonce'];
$sVerifyEchoStr = $_GET['echostr'];


$sEchoStr = "";

// call verify function
$errCode = $wxcpt->VerifyURL($sVerifyMsgSig, $sVerifyTimeStamp, $sVerifyNonce, $sVerifyEchoStr, $sEchoStr);
if ($errCode == 0) {
	echo $sEchoStr . "\n";
} else {
	print("ERR: " . $errCode . "\n\n");
}


/* 解析收到的消息 */


$sReqMsgSig = $_GET['msg_signature'];
$sReqTimeStamp = $_GET['timestamp'];
$sReqNonce = $_GET['nonce'];



// post请求的密文数据

//$sReqData = HttpUtils.PostData();
//$sReqData = $GLOBALS['HTTP_RAW_POST_DATA'];
//$sReqData = "<xml><ToUserName><![CDATA[wx5823bf96d3bd56c7]]></ToUserName><Encrypt><![CDATA[RypEvHKD8QQKFhvQ6QleEB4J58tiPdvo+rtK1I9qca6aM/wvqnLSV5zEPeusUiX5L5X/0lWfrf0QADHHhGd3QczcdCUpj911L3vg3W/sYYvuJTs3TUUkSUXxaccAS0qhxchrRYt66wiSpGLYL42aM6A8dTT+6k4aSknmPj48kzJs8qLjvd4Xgpue06DOdnLxAUHzM6+kDZ+HMZfJYuR+LtwGc2hgf5gsijff0ekUNXZiqATP7PF5mZxZ3Izoun1s4zG4LUMnvw2r+KqCKIw+3IQH03v+BCA9nMELNqbSf6tiWSrXJB3LAVGUcallcrw8V2t9EL4EhzJWrQUax5wLVMNS0+rUPA3k22Ncx4XXZS9o0MBH27Bo6BpNelZpS+/uh9KsNlY6bHCmJU9p8g7m3fVKn28H3KDYA5Pl/T8Z1ptDAVe0lXdQ2YoyyH2uyPIGHBZZIs2pDBS8R07+qN+E7Q==]]></Encrypt><AgentID><![CDATA[218]]></AgentID></xml>";
$sReqData = file_get_contents("php://input"); //接收post数据

// $myfile = fopen("receive.txt", "w");
// 	fwrite($myfile, $sReqData);
// 	fclose($myfile);

$sMsg = "";  // 解析之后的明文
$errCode = $wxcpt->DecryptMsg($sReqMsgSig, $sReqTimeStamp, $sReqNonce, $sReqData, $sMsg);

//打印解析后的XML
// $myfile = fopen("receive_final.txt", "w");
// 	fwrite($myfile, $sMsg);
// 	fclose($myfile);

//XML去掉CDATA并且转化为json对象
$XML = simplexml_load_string($sMsg, 'SimpleXMLElement', LIBXML_NOCDATA);
$eJson = json_encode($XML);
$dJson = json_decode($eJson);

//获取JSON对象的格式
// ob_start();  
// var_dump($dJson);  
// $result = ob_get_clean();

//打印到文件
// $myfile = fopen("XMLobj.txt", "w");
// 	fwrite($myfile, $result);
// 	fclose($myfile);
	
/* 回复 */

/*
为了将此段明文回复给用户，企业应：
1.自己生成时间时间戳(timestamp),随机数字串(nonce)以便生成消息体签名，也可以直接用从公众平台的post url上解析出的对应值。
2.将明文加密得到密文。
3.用密文，步骤1生成的timestamp,nonce和企业在公众平台设定的token生成消息体签名。
4.将密文，消息体签名，时间戳，随机数字串拼接成xml格式的字符串，发送给企业号。
以上2，3，4步可以用公众平台提供的库函数EncryptMsg来实现。
*/

// 需要发送的明文
// date_default_timezone_set('PRC');
// $time = date('Y-m-d h:i:s', time());

$sRespData = "<xml><ToUserName><![CDATA[mycreate]]></ToUserName><FromUserName><![CDATA[wx5823bf96d3bd56c7]]></FromUserName><CreateTime>1348831860</CreateTime><MsgType><![CDATA[text]]></MsgType><Content><![CDATA[]]></Content><MsgId>1234567890123456</MsgId><AgentID>128</AgentID></xml>";
$sEncryptMsg = ""; //xml格式的密文
$errCode = $wxcpt->EncryptMsg($sRespData, $sReqTimeStamp, $sReqNonce, $sEncryptMsg);
if ($errCode == 0) {
    var_dump($sEncryptMsg);
	print("done \n");
	// TODO:
	// 加密成功，企业需要将加密之后的sEncryptMsg返回
	// HttpUtils.SetResponce($sEncryptMsg);  //回复加密之后的密文
	echo $sEncryptMsg;

// 	// $myfile = fopen("error.txt", "w");
// 	// fwrite($myfile, $errCode);
// 	// fclose($myfile);
	
} else { 
	print("ERR: " . $errCode . "\n\n");

	// $myfile = fopen("error.txt", "w");
	// fwrite($myfile, $errCode);
	// fclose($myfile);
	// // exit(-1); 
}

$str = "init";
$user = $dJson->FromUserName;
if ($dJson->MsgType == "text") {
    $input = $dJson->Content;
	//$input = '刚才说“'.$dJson->Content.'”的人是个大帅哥';
	//$input = 'php交给python处理的信息['."用户发送的信息[$dJson->Content]".']';
	//$str = exec("python /var/www/html/sample/python.py $input");
	$str = exec("python /var/www/html/robot/FAQrobot.py $input");
}
else 
	$str = "请发送文字信息";

//  include_once("MessageTest.php");

include_once("../src/CorpAPI.class.php");
include_once("../src/ServiceCorpAPI.class.php");
include_once("../src/ServiceProviderAPI.class.php");

// 

$config = require('./config.php');
// 

$agentId = $config['APP_ID'];

try{
    $api = new CorpAPI($config['CORP_ID'], $config['APP_SECRET']);
}catch(Exception $e){
    echo $e->getMessage();
}


try { 
    //
    
    $message = new Message();
    {
        $message->sendToAll = false;
        $message->touser = array("YiZhiBingLingLongTao", "LiMingYu", "d41d8cd98f00b204e9800998ecf8427e", "att1cus");
        $message->toparty = array(1, 2, 1111, 3333);
        $message->totag= array(3, 4, 22233332, 33334444);
        $message->agentid = $agentId;
        $message->safe = 0;

        $message->messageContent = new NewsMessageContent(
            array(
                new NewsArticle(
                    $title = "Got you !", 
                    $description = "Who's this cute guy testing me ?", 
                    $url = "https://work.weixin.qq.com/wework_admin/ww_mt/agenda", 
                    $picurl = "https://p.qpic.cn/pic_wework/167386225/f9ffc8f0a34f301580daaf05f225723ff571679f07e69f91/0", 
                    $btntxt = "btntxt"
                ),
            )
        );
    }
    $invalidUserIdList = null;
    $invalidPartyIdList = null;
    $invalidTagIdList = null;

    $message2=new Message();
    {
        $message2->sendToAll=null;
        $message2->touser=array($user);
        $message->toparty = array(1, 2, 1111, 3333);
        $message->totag= array(3, 4, 22233332, 33334444);
        $message2->agentid=$agentId;
        $message2->safe=0;

        $message2->messageContent=new TextMessageContent($str);
    }
    $api->MessageSend($message2, $invalidUserIdList, $invalidPartyIdList, $invalidTagIdList);
    
    // $api->MessageSend($message, $invalidUserIdList, $invalidPartyIdList, $invalidTagIdList);
    // var_dump($invalidUserIdList);
    // var_dump($invalidPartyIdList);
    // var_dump($invalidTagIdList);
} catch (Exception $e) { 
    echo $e->getMessage() . "\n";
}
