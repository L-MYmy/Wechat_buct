<?php
echo "system memory usage " . memory_get_usage() . "B\n";
?>
