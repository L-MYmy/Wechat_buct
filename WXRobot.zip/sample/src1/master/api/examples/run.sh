##
 # Copyright (C) 2017 All rights reserved.
 #   
 # @File run.sh
 # @Brief 
 # @Author abelzhu, abelzhu@tencent.com
 # @Version 1.0
 # @Date 2017-12-13
 #
 #
 
#!/bin/bash
 
php AgentTest.php

php BatchTest.php 

php CheckinTest.php

php DepartmentTest.php 

php JsApiTest.php 

php MediaTest.php   

php MenuTest.php  

php MessageTest.php

php OauthTest.php  

php PayTest.php        

php ServiceCorpTest.php

php ServiceProviderTest.php 

php TagTest.php 

php UserTest.php
