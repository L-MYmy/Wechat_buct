<?php /*
 * Copyright (C) 2017 All rights reserved.
 *   
 * @File MessageTest.php
 * @Brief 
 * @Author abelzhu, abelzhu@tencent.com
 * @Version 1.0
 * @Date 2017-12-26
 *
 */
echo "33 ";
include_once("../src/CorpAPI.class.php");
include_once("../src/ServiceCorpAPI.class.php");
include_once("../src/ServiceProviderAPI.class.php");

// 

$config = require('./config.php');
// 

$agentId = $config['APP_ID'];
echo "44 ";
try{
    $api = new CorpAPI($config['CORP_ID'], $config['APP_SECRET']);
}catch(Exception $e){
    echo $e->getMessage();
}

echo "55 ";
try { 
    //
    
    $message = new Message();
    {
        $message->sendToAll = false;
        $message->touser = array("YiZhiBingLingLongTao", "LiMingYu", "d41d8cd98f00b204e9800998ecf8427e", "att1cus");
        $message->toparty = array(1, 2, 1111, 3333);
        $message->totag= array(3, 4, 22233332, 33334444);
        $message->agentid = $agentId;
        $message->safe = 0;

        $message->messageContent = new NewsMessageContent(
            array(
                new NewsArticle(
                    $title = "Got you !", 
                    $description = "Who's this cute guy testing me ?", 
                    $url = "https://work.weixin.qq.com/wework_admin/ww_mt/agenda", 
                    $picurl = "https://p.qpic.cn/pic_wework/167386225/f9ffc8f0a34f301580daaf05f225723ff571679f07e69f91/0", 
                    $btntxt = "btntxt"
                ),
            )
        );
    }
    $invalidUserIdList = null;
    $invalidPartyIdList = null;
    $invalidTagIdList = null;

    $message2=new Message();
    {
        $message2->sendToAll=null;
        $message2->touser=array("YiZhiBingLingLongTao", "LiMingYu", "d41d8cd98f00b204e9800998ecf8427e", "att1cus");
        $message->toparty = array(1, 2, 1111, 3333);
        $message->totag= array(3, 4, 22233332, 33334444);
        $message2->agentid=$agentId;
        $message2->safe=0;

        $message2->messageContent=new TextMessageContent("你是猪");
    }
    $api->MessageSend($message2, $invalidUserIdList, $invalidPartyIdList, $invalidTagIdList);
    
    // $api->MessageSend($message, $invalidUserIdList, $invalidPartyIdList, $invalidTagIdList);
    // var_dump($invalidUserIdList);
    // var_dump($invalidPartyIdList);
    // var_dump($invalidTagIdList);
} catch (Exception $e) { 
    echo $e->getMessage() . "\n";
}
