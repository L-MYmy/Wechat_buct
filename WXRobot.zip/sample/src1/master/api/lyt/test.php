<?php
$test=new Sendmessage();
$test->send();