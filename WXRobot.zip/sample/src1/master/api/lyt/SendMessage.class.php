<?php
include_once(__DIR__."/./utils/error.inc.php");
include_once(__DIR__."/./utils/Utils.class.php");
class SendMessage
{
    private $config = require('./config.php');
// 
    private $agentId = $config['APP_ID'];
    private $api = new CorpAPI($config['CORP_ID'], $config['APP_SECRET']);
    public function send()
    {
        $message2=new Message();
        {
        $message2->sendToAll=null;
        $message2->touser=array("YiZhiBingLingLongTao", "LiMingYu", "d41d8cd98f00b204e9800998ecf8427e", "att1cus");
        $message->toparty = array(1, 2, 1111, 3333);
        $message->totag= array(3, 4, 22233332, 33334444);
        $message2->agentid=$agentId;
        $message2->safe=0;

        $message2->messageContent=new TextMessageContent("你是猪");
        }
        $api->MessageSend($message2, $invalidUserIdList, $invalidPartyIdList, $invalidTagIdList);

    }
}