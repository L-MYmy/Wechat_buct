<?php
include_once("../examples/MessageTest.php");