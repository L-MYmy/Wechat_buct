###微信公众号回调模式之验证URL
from flask import Flask,request
from WXBizMsgCrypt import WXBizMsgCrypt
import xml.etree.cElementTree as ET
import sys
import pycrypto

app = Flask(__name__)

@app.route('/',methods=['GET','POST'])
def index():
    sToken = 'tiS6p'    #Token
    sEncodingAESKey = 'LJfAs7FGKWAjy9A5YGxpg9Gf7h97soR29hHR1KWMwuM'    #EncodingAESKey
    sCorpID = 'ww197c561483b1e4cb'    #CorpID
    wxcpt=WXBizMsgCrypt(sToken,sEncodingAESKey,sCorpID)
    sVerifyMsgSig=request.args.get('msg_signature')    #获取微信验证发过来的请求参数msg_signature
    sVerifyTimeStamp=request.args.get('timestamp')    #获取微信验证发过来的请求参数timestamp
    sVerifyNonce=request.args.get('nonce')    #获取微信验证发过来的请求参数nonce
    sVerifyEchoStr=request.args.get('echostr')    #获取微信验证发过来的请求参数echostr
    ret,sEchoStr=wxcpt.VerifyURL(sVerifyMsgSig, sVerifyTimeStamp,sVerifyNonce,sVerifyEchoStr)
    if (ret != 0 ):
        print "ERR: VerifyURL ret:" + ret
        sys.exit(1)
    return sEchoStr    #返回解密后的EchoStr
if __name__ == '__main__':
    app.run(host='182.92.221.222',port=6000,debug=True)