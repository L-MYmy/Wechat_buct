import pymysql;
import pandas as pd
import numpy as np

db = pymysql.connect(host="localhost", user="root", password="Practice2021.", db="QA")
# 使用 cursor() 方法创建一个游标对象 cursor

# 使用 execute()  方法执行 SQL 查询
# 插入语句
# cursor.execute("insert into answer(answer_id, content) values(2, '如何减肥');")

#select语句
cur = db.cursor() 
sql = 'select content from answer;'
df = pd.read_sql(sql, con=db)
df1 = np.array(df)#先使用array()将DataFrame转换一下
df2 = df1.tolist()#再将转换后的数据用tolist()转成列表
for t in df2:
    print(t)
# 使用 fetchone() 方法获取单条数据.
# while 1:
#     data = cursor.fetchone()
#     if data is None:
#         break
#     print(data)

db.close()